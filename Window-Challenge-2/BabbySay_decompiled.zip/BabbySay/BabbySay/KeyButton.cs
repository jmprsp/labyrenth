﻿namespace BabbySay
{
    using System;
    using System.Media;
    using System.Windows.Forms;

    internal class KeyButton : Button
    {
        private int key_number;
        private SoundPlayer key_player;
        private bool key_type;

        public bool is_black
        {
            get
            {
                return this.key_type;
            }
            set
            {
                this.key_type = value;
            }
        }

        public int number
        {
            get
            {
                return this.key_number;
            }
            set
            {
                this.key_number = value;
            }
        }

        public SoundPlayer player
        {
            get
            {
                return this.key_player;
            }
            set
            {
                this.key_player = value;
            }
        }
    }
}

