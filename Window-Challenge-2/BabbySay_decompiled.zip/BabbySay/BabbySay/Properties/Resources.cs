﻿namespace BabbySay.Properties
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Resources;
    using System.Runtime.CompilerServices;

    [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), DebuggerNonUserCode, CompilerGenerated]
    internal class Resources
    {
        private static CultureInfo resourceCulture;
        private static System.Resources.ResourceManager resourceMan;

        internal Resources()
        {
        }

        internal static UnmanagedMemoryStream b_0
        {
            get
            {
                return ResourceManager.GetStream("b_0", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_1
        {
            get
            {
                return ResourceManager.GetStream("b_1", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_10
        {
            get
            {
                return ResourceManager.GetStream("b_10", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_11
        {
            get
            {
                return ResourceManager.GetStream("b_11", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_12
        {
            get
            {
                return ResourceManager.GetStream("b_12", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_13
        {
            get
            {
                return ResourceManager.GetStream("b_13", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_14
        {
            get
            {
                return ResourceManager.GetStream("b_14", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_15
        {
            get
            {
                return ResourceManager.GetStream("b_15", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_16
        {
            get
            {
                return ResourceManager.GetStream("b_16", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_17
        {
            get
            {
                return ResourceManager.GetStream("b_17", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_18
        {
            get
            {
                return ResourceManager.GetStream("b_18", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_19
        {
            get
            {
                return ResourceManager.GetStream("b_19", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_2
        {
            get
            {
                return ResourceManager.GetStream("b_2", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_20
        {
            get
            {
                return ResourceManager.GetStream("b_20", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_21
        {
            get
            {
                return ResourceManager.GetStream("b_21", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_22
        {
            get
            {
                return ResourceManager.GetStream("b_22", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_23
        {
            get
            {
                return ResourceManager.GetStream("b_23", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_24
        {
            get
            {
                return ResourceManager.GetStream("b_24", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_25
        {
            get
            {
                return ResourceManager.GetStream("b_25", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_3
        {
            get
            {
                return ResourceManager.GetStream("b_3", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_35
        {
            get
            {
                return ResourceManager.GetStream("b_35", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_4
        {
            get
            {
                return ResourceManager.GetStream("b_4", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_5
        {
            get
            {
                return ResourceManager.GetStream("b_5", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_6
        {
            get
            {
                return ResourceManager.GetStream("b_6", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_7
        {
            get
            {
                return ResourceManager.GetStream("b_7", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_8
        {
            get
            {
                return ResourceManager.GetStream("b_8", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream b_9
        {
            get
            {
                return ResourceManager.GetStream("b_9", resourceCulture);
            }
        }

        internal static byte[] babby_yell
        {
            get
            {
                return (byte[]) ResourceManager.GetObject("babby_yell", resourceCulture);
            }
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static CultureInfo Culture
        {
            get
            {
                return resourceCulture;
            }
            set
            {
                resourceCulture = value;
            }
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        internal static System.Resources.ResourceManager ResourceManager
        {
            get
            {
                if (resourceMan == null)
                {
                    resourceMan = new System.Resources.ResourceManager("BabbySay.Properties.Resources", typeof(Resources).Assembly);
                }
                return resourceMan;
            }
        }

        internal static UnmanagedMemoryStream w_0
        {
            get
            {
                return ResourceManager.GetStream("w_0", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_1
        {
            get
            {
                return ResourceManager.GetStream("w_1", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_10
        {
            get
            {
                return ResourceManager.GetStream("w_10", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_11
        {
            get
            {
                return ResourceManager.GetStream("w_11", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_12
        {
            get
            {
                return ResourceManager.GetStream("w_12", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_13
        {
            get
            {
                return ResourceManager.GetStream("w_13", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_14
        {
            get
            {
                return ResourceManager.GetStream("w_14", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_15
        {
            get
            {
                return ResourceManager.GetStream("w_15", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_16
        {
            get
            {
                return ResourceManager.GetStream("w_16", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_17
        {
            get
            {
                return ResourceManager.GetStream("w_17", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_18
        {
            get
            {
                return ResourceManager.GetStream("w_18", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_19
        {
            get
            {
                return ResourceManager.GetStream("w_19", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_2
        {
            get
            {
                return ResourceManager.GetStream("w_2", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_20
        {
            get
            {
                return ResourceManager.GetStream("w_20", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_21
        {
            get
            {
                return ResourceManager.GetStream("w_21", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_22
        {
            get
            {
                return ResourceManager.GetStream("w_22", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_23
        {
            get
            {
                return ResourceManager.GetStream("w_23", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_24
        {
            get
            {
                return ResourceManager.GetStream("w_24", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_25
        {
            get
            {
                return ResourceManager.GetStream("w_25", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_26
        {
            get
            {
                return ResourceManager.GetStream("w_26", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_27
        {
            get
            {
                return ResourceManager.GetStream("w_27", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_28
        {
            get
            {
                return ResourceManager.GetStream("w_28", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_29
        {
            get
            {
                return ResourceManager.GetStream("w_29", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_3
        {
            get
            {
                return ResourceManager.GetStream("w_3", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_30
        {
            get
            {
                return ResourceManager.GetStream("w_30", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_31
        {
            get
            {
                return ResourceManager.GetStream("w_31", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_32
        {
            get
            {
                return ResourceManager.GetStream("w_32", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_33
        {
            get
            {
                return ResourceManager.GetStream("w_33", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_34
        {
            get
            {
                return ResourceManager.GetStream("w_34", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_35
        {
            get
            {
                return ResourceManager.GetStream("w_35", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_36
        {
            get
            {
                return ResourceManager.GetStream("w_36", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_37
        {
            get
            {
                return ResourceManager.GetStream("w_37", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_4
        {
            get
            {
                return ResourceManager.GetStream("w_4", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_49
        {
            get
            {
                return ResourceManager.GetStream("w_49", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_5
        {
            get
            {
                return ResourceManager.GetStream("w_5", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_50
        {
            get
            {
                return ResourceManager.GetStream("w_50", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_51
        {
            get
            {
                return ResourceManager.GetStream("w_51", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_6
        {
            get
            {
                return ResourceManager.GetStream("w_6", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_7
        {
            get
            {
                return ResourceManager.GetStream("w_7", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_8
        {
            get
            {
                return ResourceManager.GetStream("w_8", resourceCulture);
            }
        }

        internal static UnmanagedMemoryStream w_9
        {
            get
            {
                return ResourceManager.GetStream("w_9", resourceCulture);
            }
        }
    }
}

